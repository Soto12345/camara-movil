package com.example.camara

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.zxing.integration.android.IntentIntegrator

class activity_lector : AppCompatActivity() {
    private lateinit var codigo:EditText
    private lateinit var descripcion:EditText
    private lateinit var btnEscanear:Button
    private lateinit var btnCapturar:Button
    private lateinit var btnLimpiar:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lector)
        codigo=findViewById(R.id.edtCodigo)
        descripcion=findViewById(R.id.edtDescripcion)
        btnEscanear=findViewById(R.id.btnEscanear)
        btnCapturar=findViewById(R.id.btnRegistrar)
        btnLimpiar=findViewById(R.id.btnLipiar)

        //eventos

        btnEscanear.setOnClickListener{escanearCodigo()}
        btnCapturar.setOnClickListener{
            if(codigo.text.toString().isNotEmpty() && descripcion.text.toString().isNotEmpty())
            {
                Toast.makeText(this,"Datos capturados",Toast.LENGTH_SHORT).show()
                limpiar();
            }else{
                Toast.makeText(this,"Debes registrar datos",Toast.LENGTH_LONG).show()
            }
        }
        btnLimpiar.setOnClickListener{limpiar()}
    }
    private fun escanearCodigo()
    {
        //instancia para leer codigos
        val intentIntegrator=IntentIntegrator(this@activity_lector)
        //definir el tipo de codigo  a leer cualquier formato de codigo
        intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES)
        intentIntegrator.setPrompt("Lector de codigos")
        intentIntegrator.setCameraId(0)
        intentIntegrator.setBeepEnabled(true)
        intentIntegrator.setBarcodeImageEnabled(true)
        intentIntegrator.initiateScan()
    }
    //metodo para determinar que hacer despues de leer el codigo

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        val intentResult=IntentIntegrator.parseActivityResult(requestCode,resultCode,data)
        //validar que no este vacia
        if(intentResult != null)
        {
            //validar que leyo informacion
            if(intentResult.contents ==null)
            {
                Toast.makeText(this,"Lectura cancelada",Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this,"codigo leido",Toast.LENGTH_SHORT).show()
                //colocar el codigo en la caja de texto
                codigo.setText(intentResult.contents)
            }
        }else{
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
    private fun limpiar()
    {

    }
}